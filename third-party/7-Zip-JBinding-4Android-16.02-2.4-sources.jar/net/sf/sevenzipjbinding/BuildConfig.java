/**
 * Automatically generated file. DO NOT MODIFY
 */
package net.sf.sevenzipjbinding;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "net.sf.sevenzipjbinding";
  public static final String BUILD_TYPE = "release";
  // 
  public static final String BUILT_DATE = "2025-04-23T23:35:22.48512293Z";
  // 
  public static final String VERSION_NAME = "16.02-2.4";
}
